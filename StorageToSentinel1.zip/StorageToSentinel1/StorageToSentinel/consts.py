"""This file contains all constants."""
import os

LOG_LEVEL = os.environ.get("LogLevel", "")
LOGS_STARTS_WITH = "Netskope : "
NETSKOPE_DATA_CONNECTOR = "NTSKP Data Connector"
WORKSPACE_KEY = os.environ.get("WorkspaceKey", "")
WORKSPACE_ID = os.environ.get("WorkspaceId", "")
CONNECTION_STRING = os.environ.get("Connection_String","")
NETSKOPESTATEMANAGERTOSENTINEL = "NetskopeStateManagerToSentinel"