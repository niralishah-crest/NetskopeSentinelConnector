"""Init for Netskope Azure storage to Sentinel."""

# This function is not intended to be invoked directly. Instead it will be
# triggered by an orchestrator function.
# Before running this sample, please:
# - create a Durable orchestration function
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import json
from .netskope_azure_storage_to_sentinel import NetskopeAzureStorageToSentinel
from .remove_duplicates_in_azure_storage import RemoveDuplicatesInAzureStorage


def main(sharename: str) -> str:
    """Driver method for azure storage to sentinel."""
    remove_duplicates_obj = RemoveDuplicatesInAzureStorage(sharename)
    remove_duplicates_obj.driver_code()
    state_manager_to_sentinel_obj = NetskopeAzureStorageToSentinel(sharename)
    state_manager_to_sentinel_obj.driver_code()
