"""Netskope azure storage to sentinel."""
import inspect
import json
import sys
import time
from azure.core.exceptions import ResourceNotFoundError
from azure.storage.fileshare import ShareDirectoryClient
from ..SharedCode.state_manager import StateManager
from ..SharedCode import consts
from .sentinel import post_data
from ..SharedCode.logger import applogger
from ..SharedCode.netskope_exception import NetskopeException


class NetskopeAzureStorageToSentinel:
    """Netskope azure storage to sentinel utility class."""

    def __init__(self, prefix_to_scan: str, share_name: str) -> None:
        """Initialize variables."""
        self.arr_to_return = []
        self.prefix_to_scan = prefix_to_scan
        self.share_name = share_name

    def separate_data_into_chunks(self, result_data):
        """Divide large data into small chunks.

        Args:
            result_data (list): list of chunks
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if sys.getsizeof(json.dumps(result_data)) < 26214400:
                return result_data
            count_of_data = int(len(result_data))
            req_size = int(count_of_data / 2)
            new_arr1 = result_data[0:req_size]
            new_arr2 = result_data[req_size:count_of_data]
            self.arr_to_return.append(self.separate_data_into_chunks(new_arr1))
            self.arr_to_return.append(self.separate_data_into_chunks(new_arr2))
            return
        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} : Error while separating large netskope data in small chunks.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} : Error while separating large netskope data in small chunks, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                    error,
                )
            )
            raise NetskopeException()

    def return_file_names_to_query(self, file_names: list, prefix_to_search: str):
        """Return the file names for current execution.

        Args:
            file_names (list): list of file
            prefix_to_search (str): file name prefix to search

        Returns:
            list: list of files
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            current_timestamp = int(time.time())
            limit_timestamp = current_timestamp - 660
            file_names_to_query = []
            for file in file_names:
                if prefix_to_search in file and "epoch" not in file and "failed" not in file:
                    if int(file.split("_")[-2]) < limit_timestamp:
                        file_names_to_query.append(file)
            return file_names_to_query
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} : Error while searching file names, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                    error,
                )
            )
            raise NetskopeException()

    def delete_file_from_file_share(self, file_name, parent_dir):
        """Delete the file from azure file share.

        Args:
            file_name (str): name of the file to delete
            parent_dir (ShareDirectory.from_connection_string): Object of ShareDirectory to perform operations
            on file share.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            parent_dir.delete_file(file_name)
            applogger.debug(
                "{}(method={}) : {} : File deleted successfully, filename-{}.".format(
                    consts.LOGS_STARTS_WITH, __method_name, consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL, file_name
                )
            )
        except ResourceNotFoundError:
            applogger.info(
                "{}(method={}) : {} : File not found while deleting, filename-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                    file_name,
                )
            )
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} : Error while deleting file, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                    error,
                )
            )
            raise NetskopeException()

    def get_files_list(self, parent_dir):
        """Get list of file names from directory.

        Args:
            parent_dir (ShareDirectory.from_connection_string): Object of ShareDirectory to perform operations
            on file share.

        Returns:
            list: list of files
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            files_list = list(parent_dir.list_directories_and_files())
            file_names = []
            if (len(files_list)) > 0:
                for file in files_list:
                    file_names.append(file["name"])
                return file_names
            else:
                return None
        except ResourceNotFoundError:
            applogger.error(
                "{}(method={}) : {} : No storage directory found.".format(
                    consts.LOGS_STARTS_WITH, __method_name, consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL
                )
            )
            return None
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} : Error while getting list of files, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                    error,
                )
            )
            raise NetskopeException()

    def get_data_from_file(self, file_name):
        """Read file from azure storage.

        Args:
            file_name (str): file name to read

        Returns:
            json: Netskope data
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            state_manager_obj = StateManager(consts.CONNECTION_STRING, file_name, self.share_name)
            raw_data = state_manager_obj.get(consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL)
            json_data = json.loads(raw_data)
            return json_data
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} : Error while reading netskope data from File, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                    error,
                )
            )
            raise NetskopeException()

    def driver_code(self):
        """Driver code for azure storage to sentinel."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            state_manager_obj = StateManager(
                consts.CONNECTION_STRING, "DataSent_{}".format(str(int(time.time()))), self.share_name
            )
            parent_dir = ShareDirectoryClient.from_connection_string(
                conn_str=consts.CONNECTION_STRING,
                share_name=self.share_name,
                directory_path="",
            )
            state_manager_obj.post("0")
            file_names_to_query = self.get_files_list(parent_dir)
            file_names_to_get_data = self.return_file_names_to_query(file_names_to_query, self.prefix_to_scan)
            for file in file_names_to_get_data:
                count_data = int(state_manager_obj.get(consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL))
                file_data = self.get_data_from_file(file)
                if file_data is not None:
                    if sys.getsizeof(json.dumps(file_data["result"])) > 26214400:
                        self.separate_data_into_chunks(file_data["result"])
                        for data in self.arr_to_return:
                            post_data(json.dumps(data), self.prefix_to_scan)
                        self.arr_to_return = []
                    else:
                        post_data(json.dumps(file_data["result"]), self.prefix_to_scan)
                    applogger.info(
                        "{}(method={}) : {} : Netskope data posted successfully of file : {}.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                            file,
                        )
                    )
                    count_data += 1
                    state_manager_obj.post(str(count_data))
                self.delete_file_from_file_share(file, parent_dir)
        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} : Error occurred in Netskope azure storage to sentinel.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} : Error occurred in netskope azure storage to sentinel, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETSKOPE_AZURE_STORAGE_TO_SENTINEL,
                    error,
                )
            )
            raise NetskopeException()
