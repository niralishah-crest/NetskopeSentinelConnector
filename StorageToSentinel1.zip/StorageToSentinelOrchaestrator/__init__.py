# This function is not intended to be invoked directly. Instead it will be
# triggered by an HTTP starter function.
# Before running this sample, please:
# - create a Durable activity function (default name is "Hello")
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import inspect
import logging
import json

from azure.durable_functions import DurableOrchestrationContext, Orchestrator
from azure.storage.fileshare import ShareServiceClient
from ..SharedCode import consts
from ..SharedCode.logger import applogger
from ..SharedCode.netskope_exception import NetskopeException


def get_share_names():
    __method_name = inspect.currentframe().f_code.co_name
    try:
        parent_dir = ShareServiceClient.from_connection_string(
            conn_str=consts.CONNECTION_STRING,
        )
        share_names_json = parent_dir.list_shares()
        share_names_list = [
            i.get("name") for i in share_names_json if "events" in i.get("name")# or "events" in i.get("name")
        ]
        return share_names_list
    except KeyError as key_error:
        applogger.error(
            "{}(method={}) : {}: Error while accessing the data key in the response. Error-{}".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETKOPE_TO_AZURE_STORAGE,
                key_error,
            )
        )
        raise NetskopeException()
    except Exception as error:
        applogger.error(
            "{}(method={}) : {}: Error while fetching the share names from azure storage account. Error-{}".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETKOPE_TO_AZURE_STORAGE,
                error,
            )
        )
        raise NetskopeException()


def orchestrator_function(context: DurableOrchestrationContext):
    share_names = get_share_names()
    # share_names = ['eventsnetworkdata']
    parallel_tasks = [context.call_activity("StorageToSentinel", share) for share in share_names]
    outputs = yield context.task_all(parallel_tasks)
    return str(outputs)


main = Orchestrator.create(orchestrator_function)
