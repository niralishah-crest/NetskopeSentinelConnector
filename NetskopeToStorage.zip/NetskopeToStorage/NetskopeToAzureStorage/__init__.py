# This function is not intended to be invoked directly. Instead it will be
# triggered by an orchestrator function.
# Before running this sample, please:
# - create a Durable orchestration function
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

import inspect
import json
from .netskope_to_azure_storage import NetskopeToAzureStorage
from ..SharedCode.logger import applogger
from ..SharedCode.netskope_exception import NetskopeException
from ..SharedCode import consts


async def main(typesubtypedata: str) -> str:
    """main function"""
    __method_name = inspect.currentframe().f_code.co_name
    try:
        json_decoded_data = json.loads(typesubtypedata)
        netskope_to_azure_storage = NetskopeToAzureStorage(
            json_decoded_data.get("type_of_data"), json_decoded_data.get("sub_type")
        )
        await netskope_to_azure_storage.driver_code()
    except NetskopeException:
        applogger.error(
            "{}(method={}) : {} : Error while executing NetskopeToAzureStorage.".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETKOPE_TO_AZURE_STORAGE,
            )
        )
    except Exception as error:
        applogger.error(
            "{}(method={}) : {} : Error while executing NetskopeToAzureStorage. Error-{}".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETKOPE_TO_AZURE_STORAGE,
                error,
            )
        )
