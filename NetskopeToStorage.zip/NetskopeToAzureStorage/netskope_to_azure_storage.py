"""Fetch Netskope data and post to azure storage."""
import inspect
import json
import time
import aiohttp
import asyncio

from SharedCode.netskope_exception import NetskopeException
from .netskope_api_async import NetskopeAPIAsync
from ..SharedCode.state_manager import StateManager
from ..SharedCode.logger import applogger
from ..SharedCode import consts
from ..SharedCode.validate_params import validate_parameters


class NetskopeToAzureStorage:
    """Netskope to azure storage utility class."""

    def __init__(self, type_of_data, sub_type) -> None:
        """Initialize variables.

        Args:
            type_of_data (str): type of Netskope data
            sub_type (str): subtype of Netskope data
        """
        self.iterators = None
        self.starttime = int(time.time())
        self.netskope_api_async_obj = NetskopeAPIAsync(type_of_data, sub_type)
        self.share_name = type_of_data + sub_type + "data"
        self.type_of_data = type_of_data
        self.sub_type = sub_type
        self.nskp_data_type_for_logging = self.type_of_data + "_" + self.sub_type
        try:
            validate_parameters(consts.NETKOPE_TO_AZURE_STORAGE)
        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while initializing the class.".format(
                    consts.LOGS_STARTS_WITH,
                    "__init__",
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()

    def is_response_empty(self, json_response):
        """Check if response is empty or not.

        Args:
            json_response (dict): Response from the netskope api.

        Raises:
            NetskopeException: Netskope Custom Exception.

        Returns:
            bool: True if response is empty else False.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if len(json_response.get("result")) == 0:
                applogger.info(
                    "{}(method={}) : {} ({}) : The data returned is empty. Continuing to next iteration.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                    )
                )
                return True
        except KeyError as key_error:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while accessing the data key in the response. Error-{}".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    key_error,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} ({}) : Unknown Error. Error-{}".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    error,
                )
            )
            raise NetskopeException()
        return False

    async def honour_wait_time(self, data):
        """Honour the wait time returned in the response.

        Args:
            data (dict): The response returned by the netskope api.

        Raises:
            NetskopeException: Netskope custom exception.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            wait_time = int(data.get("wait_time"))
            if wait_time > 0:
                applogger.info(
                    "{}(method={}) : {} ({}) : The wait time returned is {}. Sleeping....".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                        wait_time,
                    )
                )
                await asyncio.sleep(wait_time)
        except KeyError as key_error:
            applogger.error(
                "{}(method={}) : {} ({}) : The Key wait_time not found. Error-{}".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    key_error,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while honouring wait time. Error-{}".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    error,
                )
            )
            raise NetskopeException()

    async def reset_iterators(self, index, last_epoch, is_last_data_empty, session):
        """Reset Netskope iterator.

        Args:
            index (int): index of iterator
            last_epoch (int): last epoch time
            session (aiohttp.ClientSession): session object

        Returns:
            int: updated epoch time
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if not is_last_data_empty:
                last_epoch_save_obj = StateManager(
                    consts.CONNECTION_STRING,
                    "{}_end_epoch_{}".format(index, str(int(time.time()))),
                    self.share_name,
                )
                last_epoch_save_obj.post(str(last_epoch))
            updated_epoch = 400 + last_epoch
            temp_state_manager_obj = StateManager(
                consts.CONNECTION_STRING,
                "{}_start_epoch".format(index),
                self.share_name,
            )
            url = self.netskope_api_async_obj.url_builder(index, updated_epoch)
            data = await self.netskope_api_async_obj.aio_http_handler(url, session)
            temp_state_manager_obj.post(str(updated_epoch))
            if not self.is_response_empty(data):
                applogger.info(
                    "{}(method={}) : {} ({}) : Reset epoch {} for iterator {}.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                        updated_epoch,
                        index,
                    )
                )
                epoch = int(data.get("timestamp_hwm"))
                state_manager_obj_to_post_data = StateManager(
                    consts.CONNECTION_STRING,
                    "{}_{}_{}_{}".format(index, str(self.starttime), str(epoch), str(int(time.time()))),
                    self.share_name,
                )
                state_manager_obj_to_post_data.post(json.dumps(data))
                start_epoch_state_manager_obj_for_duplicate_handle = StateManager(
                    consts.CONNECTION_STRING,
                    "{}_start_epoch_{}".format(index, str(int(time.time()))),
                    self.share_name,
                )
                start_epoch_state_manager_obj_for_duplicate_handle.post(str(epoch))
            await self.honour_wait_time(data)
            return updated_epoch
        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while reseting iterators.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while reseting iterators, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    error,
                )
            )
            raise NetskopeException()

    async def initiate_iterators(self):
        """Initialize Netskope iterators."""
        __method_name = inspect.currentframe().f_code.co_name
        applogger.info(
            "{}(method={}) : {} ({}) : Initializing the iterators.".format(
                consts.LOGS_STARTS_WITH,
                __method_name,
                consts.NETKOPE_TO_AZURE_STORAGE,
                self.nskp_data_type_for_logging,
            )
        )
        try:
            iterators_state_manager_obj = StateManager(consts.CONNECTION_STRING, "iteratorsname", self.share_name)
            self.iterators = []
            for i in range(4):
                self.iterators.append(
                    "{}{}NSKPIterator{}_{}".format(self.type_of_data, self.sub_type, str(int(time.time())), i)
                )
            iterators_state_manager_obj.post(json.dumps(self.iterators))
            async with aiohttp.ClientSession(
                headers={
                    "User-Agent": "Netskope MSSentinel",
                    "Netskope-Api-Token": consts.NETSKOPE_TOKEN,
                }
            ) as session:
                is_first_iterator = True
                for iterator in self.iterators:
                    if is_first_iterator:
                        url = self.netskope_api_async_obj.url_builder(iterator, "head")
                        data = await self.netskope_api_async_obj.aio_http_handler(url, session)
                        epoch = int(data.get("timestamp_hwm"))
                        applogger.info(
                            "{}(method={}) : {} ({}) : Initial epoch for first iterator {} is {}.".format(
                                consts.LOGS_STARTS_WITH,
                                __method_name,
                                consts.NETKOPE_TO_AZURE_STORAGE,
                                self.nskp_data_type_for_logging,
                                iterator,
                                epoch,
                            )
                        )
                        is_data_empty = self.is_response_empty(data)
                        is_first_iterator = False
                    else:
                        epoch += 100
                        applogger.info(
                            "{}(method={}) : {} ({}) : Initial epoch for {} is {}.".format(
                                consts.LOGS_STARTS_WITH,
                                __method_name,
                                consts.NETKOPE_TO_AZURE_STORAGE,
                                self.nskp_data_type_for_logging,
                                iterator,
                                epoch,
                            )
                        )
                        url = self.netskope_api_async_obj.url_builder(iterator, epoch)
                        data = await self.netskope_api_async_obj.aio_http_handler(url, session)
                        is_data_empty = self.is_response_empty(data)
                        epoch = int(data.get("timestamp_hwm"))
                        if not is_data_empty:
                            start_epoch_state_manager_obj_for_duplicate_handle = StateManager(
                                consts.CONNECTION_STRING,
                                "{}_start_epoch_{}".format(iterator, str(int(time.time()))),
                                self.share_name,
                            )
                            start_epoch_state_manager_obj_for_duplicate_handle.post(str(epoch))
                    if not is_data_empty:
                        write_data_state_manager_obj = StateManager(
                            consts.CONNECTION_STRING,
                            "{}_{}_{}_{}".format(
                                iterator,
                                str(self.starttime),
                                str(epoch),
                                str(int(time.time())),
                            ),
                            self.share_name,
                        )
                        write_data_state_manager_obj.post(json.dumps(data))
                    is_last_failed_state_manager_obj = StateManager(
                        consts.CONNECTION_STRING,
                        "{}_is_last_failed".format(iterator),
                        self.share_name,
                    )
                    is_last_failed_state_manager_obj.post("False")
                    start_epoch_state_manager_obj = StateManager(
                        consts.CONNECTION_STRING,
                        "{}_start_epoch".format(iterator),
                        self.share_name,
                    )
                    start_epoch_state_manager_obj.post(str(epoch))
                    await self.honour_wait_time(data)
        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while Initializing iterators.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while Initializing iterators, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    error,
                )
            )
            raise NetskopeException()

    async def get_netskope_data_and_post_to_azure_storage(self, index, url, session, end_epoch):
        """Fetch Netskope data and post to azure storage.

        Args:
            index (int): index of iterator
            url (str): url for request
            session (aiohttp.ClientSession): session object
            end_epoch (int): end time epoch
        Returns:
            int: updated epoch time
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            data = await self.netskope_api_async_obj.aio_http_handler(url, session)
            epoch = int(data.get("timestamp_hwm"))
            applogger.info(
                "{}(method={}) : {} ({}) : Netskope data fetched for iterator {} till {}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    index,
                    epoch,
                )
            )
            is_data_empty = self.is_response_empty(data)
            if not is_data_empty:
                state_manager_obj_to_post_data = StateManager(
                    consts.CONNECTION_STRING,
                    "{}_{}_{}_{}".format(index, str(self.starttime), str(epoch), str(int(time.time()))),
                    self.share_name,
                )
                state_manager_obj_to_post_data.post(json.dumps(data))
                applogger.info(
                    "{}(method={}) : {} ({}) : Netskope data posted to azure storage for iterator {}.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                        index,
                    )
                )
            await self.honour_wait_time(data)
            if epoch >= end_epoch:
                applogger.info(
                    "{}(method={}) : {} ({}) : Iterator-{} : Got the 100 seconds netskope data at time-{}, "
                    "Breaking Execution.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                        index,
                        int(time.time()),
                    )
                )
                updated_start = await self.reset_iterators(index, end_epoch, is_data_empty, session)
                update_end_epoch = updated_start + 100
                return update_end_epoch
        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while getting data and post to state manager.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} ({}) : Error captured in perform_request_function, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    error,
                )
            )
            raise error

    async def check_last_failed_status_and_start_execution(self, index, end_epoch):
        """Get Netskope data.

        Args:
            index (int): index of iterator
            end_epoch (int): end epoch time
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            async with aiohttp.ClientSession(
                headers={
                    "User-Agent": "Netskope MSSentinel",
                    "Netskope-Api-Token": consts.NETSKOPE_TOKEN,
                }
            ) as session:
                is_last_failed_obj = StateManager(
                    consts.CONNECTION_STRING,
                    "{}_is_last_failed".format(index),
                    self.share_name,
                )
                while True:
                    if int(time.time()) >= self.starttime + 570:
                        applogger.info(
                            "{}(method={}) : {} ({}) : 9:30 mins executed hence breaking.".format(
                                consts.LOGS_STARTS_WITH,
                                __method_name,
                                consts.NETKOPE_TO_AZURE_STORAGE,
                                self.nskp_data_type_for_logging,
                            )
                        )
                        break
                    is_last_failed = is_last_failed_obj.get(consts.NETKOPE_TO_AZURE_STORAGE)
                    if is_last_failed == "False":
                        applogger.debug(
                            "{}(method={}) : {} ({}) : Fetching next Netskope data for iterator {}.".format(
                                consts.LOGS_STARTS_WITH,
                                __method_name,
                                consts.NETKOPE_TO_AZURE_STORAGE,
                                self.nskp_data_type_for_logging,
                                index,
                            )
                        )
                        is_last_failed_obj.post("True")
                        url = self.netskope_api_async_obj.url_builder(index, "next")
                        end_epoch_to_update = await self.get_netskope_data_and_post_to_azure_storage(
                            index, url, session, end_epoch
                        )
                        is_last_failed_obj.post("False")
                    else:
                        applogger.debug(
                            "{}(method={}) : {} ({}) : Last iteration failed for iterator {}, hence retrying.".format(
                                consts.LOGS_STARTS_WITH,
                                __method_name,
                                consts.NETKOPE_TO_AZURE_STORAGE,
                                self.nskp_data_type_for_logging,
                                index,
                            )
                        )
                        url = self.netskope_api_async_obj.url_builder(index, "resend")
                        end_epoch_to_update = await self.get_netskope_data_and_post_to_azure_storage(
                            index, url, session, end_epoch
                        )
                        is_last_failed_obj.post("False")
                    if end_epoch_to_update is not None:
                        end_epoch = end_epoch_to_update
        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} ({}) : Error while getting Netskope data.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} ({}) : Error captured in get data, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    error,
                )
            )
            raise NetskopeException()

    async def create_tasks(self, start_epochs_list):
        """Create asynchronous tasks of the get data function.

        Args:
            start_epochs_list (list): list of the start epochs

        Raises:
            NetskopeException: Netskope Custom Exception

        Returns:
            list: lists of created tasks
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            tasks_to_return = []
            for i, start_epoch in enumerate(start_epochs_list):
                end_epoch = start_epoch + 100
                if end_epoch > int(time.time()):
                    applogger.info(
                        "{}(method={}) : {} ({}) : The iterator-{} is in 100 seconds range of the current time,"
                        "hence skipping execution.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETKOPE_TO_AZURE_STORAGE,
                            self.nskp_data_type_for_logging,
                            self.iterators[i],
                        )
                    )
                    continue
                tasks_to_return.append(
                    asyncio.create_task(self.check_last_failed_status_and_start_execution(self.iterators[i], end_epoch))
                )
            return tasks_to_return
        except Exception as e:
            applogger.error(
                "{}(method={}) : {} ({}) : Error occurred in Netskope to azure storage, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    e,
                )
            )
            raise NetskopeException()

    async def driver_code(self):
        """Driver code for Netskope to azure storage."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{}(method={}) : {} ({}) : Starting execution.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            iterators_state_manager_obj = StateManager(consts.CONNECTION_STRING, "iteratorsname", self.share_name)
            self.iterators = iterators_state_manager_obj.get(consts.NETKOPE_TO_AZURE_STORAGE)
            if self.iterators is None:
                await self.initiate_iterators()
            else:
                self.iterators = json.loads(self.iterators)
            start_epochs_list = []
            iterator_initialize_successful = False
            retry_initiate_iterators = 0
            while not iterator_initialize_successful and retry_initiate_iterators < 3:
                iterator_initialize_successful = True
                for index in self.iterators:
                    start_epoch_obj = StateManager(
                        consts.CONNECTION_STRING,
                        "{}_start_epoch".format(index),
                        self.share_name,
                    )
                    start_epoch_raw = start_epoch_obj.get(consts.NETKOPE_TO_AZURE_STORAGE)
                    if start_epoch_raw is None:
                        applogger.error(
                            "{}(method={}) : {} ({}) : None returned in the start epoch for iterator-{}.".format(
                                consts.LOGS_STARTS_WITH,
                                __method_name,
                                consts.NETKOPE_TO_AZURE_STORAGE,
                                self.nskp_data_type_for_logging,
                                index,
                            )
                        )
                        iterator_initialize_successful = False
                        break
                    start_epochs_list.append(int(start_epoch_raw))
                if not iterator_initialize_successful:
                    applogger.info(
                        "{}(method={}) : {} ({}) : Initialization Failed, Retrying.".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            consts.NETKOPE_TO_AZURE_STORAGE,
                            self.nskp_data_type_for_logging,
                        )
                    )
                    await self.initiate_iterators()
                    retry_initiate_iterators += 1
            if not iterator_initialize_successful:
                applogger.error(
                    "{}(method={}) : {} ({}) : Iterator initialization was not successful."
                    "Try execution after sometime.".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        consts.NETKOPE_TO_AZURE_STORAGE,
                        self.nskp_data_type_for_logging,
                    )
                )
                raise NetskopeException()
            tasks = await self.create_tasks(start_epochs_list)
            await asyncio.gather(*tasks, return_exceptions=True)
        except NetskopeException:
            applogger.error(
                "{}(method={}) : {} ({}) : Error occurred in Netskope to azure storage.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                )
            )
            raise NetskopeException()
        except Exception as error:
            applogger.error(
                "{}(method={}) : {} ({}) : Error occurred in Netskope to azure storage, Error-{}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    consts.NETKOPE_TO_AZURE_STORAGE,
                    self.nskp_data_type_for_logging,
                    error,
                )
            )
            raise NetskopeException()
